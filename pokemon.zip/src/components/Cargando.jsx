import "./Cargando.css"

const Cargando = () => <div className="cargando"></div>

export default Cargando