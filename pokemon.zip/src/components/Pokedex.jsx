import Navbar from './Navbar';
import Pokemones from './Pokemones';

function Pokedex() {

  return (
    <>
      <Navbar />
      <Pokemones />
    </>
  );
}

export default Pokedex;
